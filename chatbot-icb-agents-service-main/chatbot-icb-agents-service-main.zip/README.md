pip install -r requirements.txt

uvicorn app.main:app --reload --port 8000 --log-level info